namespace AxisCameraControl_SIMPL_;
        // class declarations
         class AxisCamera;
     class AxisCamera 
    {
        // class delegates
        delegate FUNCTION IsInitialized ( SIMPLSHARPSTRING status );

        // class events

        // class functions
        FUNCTION PTZ ( STRING type );
        FUNCTION SavePreset ( INTEGER number );
        FUNCTION RecallPreset ( INTEGER number );
        FUNCTION Zoom ( STRING type );
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
        DelegateProperty IsInitialized isInitialized;
        STRING IpAddress[];
        STRING Username[];
        STRING Password[];
    };

