using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Linq;
using Crestron;
using Crestron.Logos.SplusLibrary;
using Crestron.Logos.SplusObjects;
using Crestron.SimplSharp;
using AxisCameraControl_SIMPL_;
using System;
using System.Text;
using OpenNETCF;
using Crestron.SimplSharp;
using Crestron.SimplSharp.Reflection.Emit;
using Crestron.SimplSharp.Reflection;
using Crestron.SimplSharp.CrestronIO;
using ProcessHacker.Common.Threading;
using Wintellect.Threading;
using SSharp.Threading;
using SSharp.CrestronThread;
using Mono.Security.Cryptography;
using SSMono.Security.Cryptography;
using SSMono.Xml;
using SSMono.Security.AccessControl;
using Mono.Math;
using SSMono.Security;
using Mono.Math.Prime;
using Mono.Security;
using Mono.Math.Prime.Generator;
using SSMono;
using SSMono.Net.Sockets;
using SSMono.Security.Principal;
using Crestron.SimplSharp.CrestronSockets;
using SSMono.Net;
using SSMono.Net.Cache;
using SSMono.Net.Security;
using Mono.Security.Protocol.Tls;
using SSMono.Security.Authentication;
using SSMono.Security.Permissions;
using SSMono.Runtime.Serialization;
using SSMono.ComponentModel;
using SSMono.Web.UI;
using SSMono.Threading;
using System.Collections;
using SSMono.Security.Cryptography.X509Certificates;
using Mono.Security.X509;
using Mono.Security.X509.Extensions;
using Mono.Security.Authenticode;

namespace UserModule_AXISCAMERA
{
    public class UserModuleClass_AXISCAMERA : SplusObject
    {
        static CCriticalSection g_criticalSection = new CCriticalSection();
        
        Crestron.Logos.SplusObjects.DigitalInput PANUP;
        Crestron.Logos.SplusObjects.DigitalInput PANDOWN;
        Crestron.Logos.SplusObjects.DigitalInput PANLEFT;
        Crestron.Logos.SplusObjects.DigitalInput PANRIGHT;
        Crestron.Logos.SplusObjects.DigitalInput ZOOMIN;
        Crestron.Logos.SplusObjects.DigitalInput ZOOMOUT;
        Crestron.Logos.SplusObjects.DigitalInput SAVEPRESET;
        Crestron.Logos.SplusObjects.DigitalInput RECALLPRESET;
        Crestron.Logos.SplusObjects.AnalogInput PRESETNUMBER;
        Crestron.Logos.SplusObjects.StringInput IPADDRESS;
        Crestron.Logos.SplusObjects.DigitalOutput PRESETSAVED;
        Crestron.Logos.SplusObjects.DigitalOutput PRESETRECALLED;
        StringParameter IP_ADDRESS;
        StringParameter USERNAME;
        StringParameter PASSWORD;
        AxisCameraControl_SIMPL_.AxisCamera CAMERA;
        object PANUP_OnPush_0 ( Object __EventInfo__ )
        
            { 
            Crestron.Logos.SplusObjects.SignalEventArgs __SignalEventArg__ = (Crestron.Logos.SplusObjects.SignalEventArgs)__EventInfo__;
            try
            {
                SplusExecutionContext __context__ = SplusThreadStartCode(__SignalEventArg__);
                
                __context__.SourceCodeLine = 18;
                while ( Functions.TestForTrue  ( ( PANUP  .Value)  ) ) 
                    { 
                    __context__.SourceCodeLine = 20;
                    CAMERA . PTZ ( "up") ; 
                    __context__.SourceCodeLine = 21;
                    Functions.Delay (  (int) ( 20 ) ) ; 
                    __context__.SourceCodeLine = 18;
                    } 
                
                
                
            }
            catch(Exception e) { ObjectCatchHandler(e); }
            finally { ObjectFinallyHandler( __SignalEventArg__ ); }
            return this;
            
        }
        
    object PANUP_OnRelease_1 ( Object __EventInfo__ )
    
        { 
        Crestron.Logos.SplusObjects.SignalEventArgs __SignalEventArg__ = (Crestron.Logos.SplusObjects.SignalEventArgs)__EventInfo__;
        try
        {
            SplusExecutionContext __context__ = SplusThreadStartCode(__SignalEventArg__);
            
            __context__.SourceCodeLine = 27;
            CAMERA . PTZ ( "stop") ; 
            
            
        }
        catch(Exception e) { ObjectCatchHandler(e); }
        finally { ObjectFinallyHandler( __SignalEventArg__ ); }
        return this;
        
    }
    
object PANDOWN_OnPush_2 ( Object __EventInfo__ )

    { 
    Crestron.Logos.SplusObjects.SignalEventArgs __SignalEventArg__ = (Crestron.Logos.SplusObjects.SignalEventArgs)__EventInfo__;
    try
    {
        SplusExecutionContext __context__ = SplusThreadStartCode(__SignalEventArg__);
        
        __context__.SourceCodeLine = 32;
        while ( Functions.TestForTrue  ( ( PANDOWN  .Value)  ) ) 
            { 
            __context__.SourceCodeLine = 34;
            CAMERA . PTZ ( "down") ; 
            __context__.SourceCodeLine = 35;
            Functions.Delay (  (int) ( 20 ) ) ; 
            __context__.SourceCodeLine = 32;
            } 
        
        
        
    }
    catch(Exception e) { ObjectCatchHandler(e); }
    finally { ObjectFinallyHandler( __SignalEventArg__ ); }
    return this;
    
}

object PANDOWN_OnRelease_3 ( Object __EventInfo__ )

    { 
    Crestron.Logos.SplusObjects.SignalEventArgs __SignalEventArg__ = (Crestron.Logos.SplusObjects.SignalEventArgs)__EventInfo__;
    try
    {
        SplusExecutionContext __context__ = SplusThreadStartCode(__SignalEventArg__);
        
        __context__.SourceCodeLine = 41;
        CAMERA . PTZ ( "stop") ; 
        
        
    }
    catch(Exception e) { ObjectCatchHandler(e); }
    finally { ObjectFinallyHandler( __SignalEventArg__ ); }
    return this;
    
}

object PANLEFT_OnPush_4 ( Object __EventInfo__ )

    { 
    Crestron.Logos.SplusObjects.SignalEventArgs __SignalEventArg__ = (Crestron.Logos.SplusObjects.SignalEventArgs)__EventInfo__;
    try
    {
        SplusExecutionContext __context__ = SplusThreadStartCode(__SignalEventArg__);
        
        __context__.SourceCodeLine = 46;
        while ( Functions.TestForTrue  ( ( PANLEFT  .Value)  ) ) 
            { 
            __context__.SourceCodeLine = 48;
            CAMERA . PTZ ( "left") ; 
            __context__.SourceCodeLine = 49;
            Functions.Delay (  (int) ( 20 ) ) ; 
            __context__.SourceCodeLine = 46;
            } 
        
        
        
    }
    catch(Exception e) { ObjectCatchHandler(e); }
    finally { ObjectFinallyHandler( __SignalEventArg__ ); }
    return this;
    
}

object PANLEFT_OnRelease_5 ( Object __EventInfo__ )

    { 
    Crestron.Logos.SplusObjects.SignalEventArgs __SignalEventArg__ = (Crestron.Logos.SplusObjects.SignalEventArgs)__EventInfo__;
    try
    {
        SplusExecutionContext __context__ = SplusThreadStartCode(__SignalEventArg__);
        
        __context__.SourceCodeLine = 55;
        CAMERA . PTZ ( "stop") ; 
        
        
    }
    catch(Exception e) { ObjectCatchHandler(e); }
    finally { ObjectFinallyHandler( __SignalEventArg__ ); }
    return this;
    
}

object PANRIGHT_OnPush_6 ( Object __EventInfo__ )

    { 
    Crestron.Logos.SplusObjects.SignalEventArgs __SignalEventArg__ = (Crestron.Logos.SplusObjects.SignalEventArgs)__EventInfo__;
    try
    {
        SplusExecutionContext __context__ = SplusThreadStartCode(__SignalEventArg__);
        
        __context__.SourceCodeLine = 60;
        while ( Functions.TestForTrue  ( ( PANRIGHT  .Value)  ) ) 
            { 
            __context__.SourceCodeLine = 62;
            CAMERA . PTZ ( "right") ; 
            __context__.SourceCodeLine = 63;
            Functions.Delay (  (int) ( 20 ) ) ; 
            __context__.SourceCodeLine = 60;
            } 
        
        
        
    }
    catch(Exception e) { ObjectCatchHandler(e); }
    finally { ObjectFinallyHandler( __SignalEventArg__ ); }
    return this;
    
}

object PANRIGHT_OnRelease_7 ( Object __EventInfo__ )

    { 
    Crestron.Logos.SplusObjects.SignalEventArgs __SignalEventArg__ = (Crestron.Logos.SplusObjects.SignalEventArgs)__EventInfo__;
    try
    {
        SplusExecutionContext __context__ = SplusThreadStartCode(__SignalEventArg__);
        
        __context__.SourceCodeLine = 69;
        CAMERA . PTZ ( "stop") ; 
        
        
    }
    catch(Exception e) { ObjectCatchHandler(e); }
    finally { ObjectFinallyHandler( __SignalEventArg__ ); }
    return this;
    
}

object ZOOMIN_OnPush_8 ( Object __EventInfo__ )

    { 
    Crestron.Logos.SplusObjects.SignalEventArgs __SignalEventArg__ = (Crestron.Logos.SplusObjects.SignalEventArgs)__EventInfo__;
    try
    {
        SplusExecutionContext __context__ = SplusThreadStartCode(__SignalEventArg__);
        
        __context__.SourceCodeLine = 74;
        while ( Functions.TestForTrue  ( ( ZOOMIN  .Value)  ) ) 
            { 
            __context__.SourceCodeLine = 76;
            CAMERA . Zoom ( "tele") ; 
            __context__.SourceCodeLine = 77;
            Functions.Delay (  (int) ( 20 ) ) ; 
            __context__.SourceCodeLine = 74;
            } 
        
        
        
    }
    catch(Exception e) { ObjectCatchHandler(e); }
    finally { ObjectFinallyHandler( __SignalEventArg__ ); }
    return this;
    
}

object ZOOMOUT_OnPush_9 ( Object __EventInfo__ )

    { 
    Crestron.Logos.SplusObjects.SignalEventArgs __SignalEventArg__ = (Crestron.Logos.SplusObjects.SignalEventArgs)__EventInfo__;
    try
    {
        SplusExecutionContext __context__ = SplusThreadStartCode(__SignalEventArg__);
        
        __context__.SourceCodeLine = 83;
        while ( Functions.TestForTrue  ( ( ZOOMOUT  .Value)  ) ) 
            { 
            __context__.SourceCodeLine = 85;
            CAMERA . Zoom ( "wide") ; 
            __context__.SourceCodeLine = 86;
            Functions.Delay (  (int) ( 20 ) ) ; 
            __context__.SourceCodeLine = 83;
            } 
        
        
        
    }
    catch(Exception e) { ObjectCatchHandler(e); }
    finally { ObjectFinallyHandler( __SignalEventArg__ ); }
    return this;
    
}

object PRESETNUMBER_OnChange_10 ( Object __EventInfo__ )

    { 
    Crestron.Logos.SplusObjects.SignalEventArgs __SignalEventArg__ = (Crestron.Logos.SplusObjects.SignalEventArgs)__EventInfo__;
    try
    {
        SplusExecutionContext __context__ = SplusThreadStartCode(__SignalEventArg__);
        
        __context__.SourceCodeLine = 92;
        if ( Functions.TestForTrue  ( ( SAVEPRESET  .Value)  ) ) 
            { 
            __context__.SourceCodeLine = 94;
            CAMERA . SavePreset ( (ushort)( PRESETNUMBER  .UshortValue )) ; 
            __context__.SourceCodeLine = 95;
            Functions.Pulse ( 10, PRESETSAVED ) ; 
            } 
        
        else 
            {
            __context__.SourceCodeLine = 97;
            if ( Functions.TestForTrue  ( ( RECALLPRESET  .Value)  ) ) 
                { 
                __context__.SourceCodeLine = 99;
                CAMERA . RecallPreset ( (ushort)( PRESETNUMBER  .UshortValue )) ; 
                __context__.SourceCodeLine = 100;
                Functions.Pulse ( 10, PRESETRECALLED ) ; 
                } 
            
            }
        
        
        
    }
    catch(Exception e) { ObjectCatchHandler(e); }
    finally { ObjectFinallyHandler( __SignalEventArg__ ); }
    return this;
    
}

object IPADDRESS_OnChange_11 ( Object __EventInfo__ )

    { 
    Crestron.Logos.SplusObjects.SignalEventArgs __SignalEventArg__ = (Crestron.Logos.SplusObjects.SignalEventArgs)__EventInfo__;
    try
    {
        SplusExecutionContext __context__ = SplusThreadStartCode(__SignalEventArg__);
        
        __context__.SourceCodeLine = 106;
        if ( Functions.TestForTrue  ( ( Functions.Length( IPADDRESS ))  ) ) 
            { 
            __context__.SourceCodeLine = 108;
            CAMERA . IpAddress  =  ( IP_ADDRESS  )  .ToString() ; 
            } 
        
        
        
    }
    catch(Exception e) { ObjectCatchHandler(e); }
    finally { ObjectFinallyHandler( __SignalEventArg__ ); }
    return this;
    
}

public override object FunctionMain (  object __obj__ ) 
    { 
    try
    {
        SplusExecutionContext __context__ = SplusFunctionMainStartCode();
        
        __context__.SourceCodeLine = 114;
        CAMERA . Username  =  ( USERNAME  )  .ToString() ; 
        __context__.SourceCodeLine = 115;
        CAMERA . Password  =  ( PASSWORD  )  .ToString() ; 
        __context__.SourceCodeLine = 117;
        if ( Functions.TestForTrue  ( ( Functions.Length( IP_ADDRESS  ))  ) ) 
            { 
            __context__.SourceCodeLine = 119;
            CAMERA . IpAddress  =  ( IP_ADDRESS  )  .ToString() ; 
            } 
        
        
        
    }
    catch(Exception e) { ObjectCatchHandler(e); }
    finally { ObjectFinallyHandler(); }
    return __obj__;
    }
    

public override void LogosSplusInitialize()
{
    SocketInfo __socketinfo__ = new SocketInfo( 1, this );
    InitialParametersClass.ResolveHostName = __socketinfo__.ResolveHostName;
    _SplusNVRAM = new SplusNVRAM( this );
    
    PANUP = new Crestron.Logos.SplusObjects.DigitalInput( PANUP__DigitalInput__, this );
    m_DigitalInputList.Add( PANUP__DigitalInput__, PANUP );
    
    PANDOWN = new Crestron.Logos.SplusObjects.DigitalInput( PANDOWN__DigitalInput__, this );
    m_DigitalInputList.Add( PANDOWN__DigitalInput__, PANDOWN );
    
    PANLEFT = new Crestron.Logos.SplusObjects.DigitalInput( PANLEFT__DigitalInput__, this );
    m_DigitalInputList.Add( PANLEFT__DigitalInput__, PANLEFT );
    
    PANRIGHT = new Crestron.Logos.SplusObjects.DigitalInput( PANRIGHT__DigitalInput__, this );
    m_DigitalInputList.Add( PANRIGHT__DigitalInput__, PANRIGHT );
    
    ZOOMIN = new Crestron.Logos.SplusObjects.DigitalInput( ZOOMIN__DigitalInput__, this );
    m_DigitalInputList.Add( ZOOMIN__DigitalInput__, ZOOMIN );
    
    ZOOMOUT = new Crestron.Logos.SplusObjects.DigitalInput( ZOOMOUT__DigitalInput__, this );
    m_DigitalInputList.Add( ZOOMOUT__DigitalInput__, ZOOMOUT );
    
    SAVEPRESET = new Crestron.Logos.SplusObjects.DigitalInput( SAVEPRESET__DigitalInput__, this );
    m_DigitalInputList.Add( SAVEPRESET__DigitalInput__, SAVEPRESET );
    
    RECALLPRESET = new Crestron.Logos.SplusObjects.DigitalInput( RECALLPRESET__DigitalInput__, this );
    m_DigitalInputList.Add( RECALLPRESET__DigitalInput__, RECALLPRESET );
    
    PRESETSAVED = new Crestron.Logos.SplusObjects.DigitalOutput( PRESETSAVED__DigitalOutput__, this );
    m_DigitalOutputList.Add( PRESETSAVED__DigitalOutput__, PRESETSAVED );
    
    PRESETRECALLED = new Crestron.Logos.SplusObjects.DigitalOutput( PRESETRECALLED__DigitalOutput__, this );
    m_DigitalOutputList.Add( PRESETRECALLED__DigitalOutput__, PRESETRECALLED );
    
    PRESETNUMBER = new Crestron.Logos.SplusObjects.AnalogInput( PRESETNUMBER__AnalogSerialInput__, this );
    m_AnalogInputList.Add( PRESETNUMBER__AnalogSerialInput__, PRESETNUMBER );
    
    IPADDRESS = new Crestron.Logos.SplusObjects.StringInput( IPADDRESS__AnalogSerialInput__, 20, this );
    m_StringInputList.Add( IPADDRESS__AnalogSerialInput__, IPADDRESS );
    
    IP_ADDRESS = new StringParameter( IP_ADDRESS__Parameter__, this );
    m_ParameterList.Add( IP_ADDRESS__Parameter__, IP_ADDRESS );
    
    USERNAME = new StringParameter( USERNAME__Parameter__, this );
    m_ParameterList.Add( USERNAME__Parameter__, USERNAME );
    
    PASSWORD = new StringParameter( PASSWORD__Parameter__, this );
    m_ParameterList.Add( PASSWORD__Parameter__, PASSWORD );
    
    
    PANUP.OnDigitalPush.Add( new InputChangeHandlerWrapper( PANUP_OnPush_0, false ) );
    PANUP.OnDigitalRelease.Add( new InputChangeHandlerWrapper( PANUP_OnRelease_1, false ) );
    PANDOWN.OnDigitalPush.Add( new InputChangeHandlerWrapper( PANDOWN_OnPush_2, false ) );
    PANDOWN.OnDigitalRelease.Add( new InputChangeHandlerWrapper( PANDOWN_OnRelease_3, false ) );
    PANLEFT.OnDigitalPush.Add( new InputChangeHandlerWrapper( PANLEFT_OnPush_4, false ) );
    PANLEFT.OnDigitalRelease.Add( new InputChangeHandlerWrapper( PANLEFT_OnRelease_5, false ) );
    PANRIGHT.OnDigitalPush.Add( new InputChangeHandlerWrapper( PANRIGHT_OnPush_6, false ) );
    PANRIGHT.OnDigitalRelease.Add( new InputChangeHandlerWrapper( PANRIGHT_OnRelease_7, false ) );
    ZOOMIN.OnDigitalPush.Add( new InputChangeHandlerWrapper( ZOOMIN_OnPush_8, false ) );
    ZOOMOUT.OnDigitalPush.Add( new InputChangeHandlerWrapper( ZOOMOUT_OnPush_9, false ) );
    PRESETNUMBER.OnAnalogChange.Add( new InputChangeHandlerWrapper( PRESETNUMBER_OnChange_10, false ) );
    IPADDRESS.OnSerialChange.Add( new InputChangeHandlerWrapper( IPADDRESS_OnChange_11, false ) );
    
    _SplusNVRAM.PopulateCustomAttributeList( true );
    
    NVRAM = _SplusNVRAM;
    
}

public override void LogosSimplSharpInitialize()
{
    CAMERA  = new AxisCameraControl_SIMPL_.AxisCamera();
    
    
}

public UserModuleClass_AXISCAMERA ( string InstanceName, string ReferenceID, Crestron.Logos.SplusObjects.CrestronStringEncoding nEncodingType ) : base( InstanceName, ReferenceID, nEncodingType ) {}




const uint PANUP__DigitalInput__ = 0;
const uint PANDOWN__DigitalInput__ = 1;
const uint PANLEFT__DigitalInput__ = 2;
const uint PANRIGHT__DigitalInput__ = 3;
const uint ZOOMIN__DigitalInput__ = 4;
const uint ZOOMOUT__DigitalInput__ = 5;
const uint SAVEPRESET__DigitalInput__ = 6;
const uint RECALLPRESET__DigitalInput__ = 7;
const uint PRESETNUMBER__AnalogSerialInput__ = 0;
const uint IPADDRESS__AnalogSerialInput__ = 1;
const uint PRESETSAVED__DigitalOutput__ = 0;
const uint PRESETRECALLED__DigitalOutput__ = 1;
const uint IP_ADDRESS__Parameter__ = 10;
const uint USERNAME__Parameter__ = 11;
const uint PASSWORD__Parameter__ = 12;

[SplusStructAttribute(-1, true, false)]
public class SplusNVRAM : SplusStructureBase
{

    public SplusNVRAM( SplusObject __caller__ ) : base( __caller__ ) {}
    
    
}

SplusNVRAM _SplusNVRAM = null;

public class __CEvent__ : CEvent
{
    public __CEvent__() {}
    public void Close() { base.Close(); }
    public int Reset() { return base.Reset() ? 1 : 0; }
    public int Set() { return base.Set() ? 1 : 0; }
    public int Wait( int timeOutInMs ) { return base.Wait( timeOutInMs ) ? 1 : 0; }
}
public class __CMutex__ : CMutex
{
    public __CMutex__() {}
    public void Close() { base.Close(); }
    public void ReleaseMutex() { base.ReleaseMutex(); }
    public int WaitForMutex() { return base.WaitForMutex() ? 1 : 0; }
}
 public int IsNull( object obj ){ return (obj == null) ? 1 : 0; }
}


}
