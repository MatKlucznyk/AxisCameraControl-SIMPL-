namespace Mono.Security.Cryptography;
        // class declarations
         class DHParameters;
         class PKCS8;
         class KeyInfo;
         class PrivateKeyInfo;
         class EncryptedPrivateKeyInfo;
         class RC4;
         class ARC4Managed;
         class MD4;
         class DiffieHellman;
         class Null;
         class NullManaged;
         class MD2;
         class DHKeyGeneration;
         class MD2Managed;
         class SHA224;
         class SHA224Managed;
         class MD4Managed;
         class DiffieHellmanManaged;
     class DHParameters 
    {
        // class delegates

        // class events

        // class functions
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
    };

     class PKCS8 
    {
        // class delegates

        // class events

        // class functions
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
    };

    static class KeyInfo // enum
    {
        static SIGNED_LONG_INTEGER PrivateKey;
        static SIGNED_LONG_INTEGER EncryptedPrivateKey;
        static SIGNED_LONG_INTEGER Unknown;
    };

     class PrivateKeyInfo 
    {
        // class delegates

        // class events

        // class functions
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
        STRING Algorithm[];
        SIGNED_LONG_INTEGER Version;
    };

     class EncryptedPrivateKeyInfo 
    {
        // class delegates

        // class events

        // class functions
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
        STRING Algorithm[];
        SIGNED_LONG_INTEGER IterationCount;
    };

     class RC4 
    {
        // class delegates

        // class events

        // class functions
        FUNCTION Clear ();
        FUNCTION GenerateIV ();
        FUNCTION GenerateKey ();
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
        SIGNED_LONG_INTEGER BlockSize;
        SIGNED_LONG_INTEGER FeedbackSize;
        SIGNED_LONG_INTEGER KeySize;
    };

     class ARC4Managed 
    {
        // class delegates

        // class events

        // class functions
        FUNCTION GenerateIV ();
        FUNCTION GenerateKey ();
        FUNCTION Clear ();
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
        SIGNED_LONG_INTEGER InputBlockSize;
        SIGNED_LONG_INTEGER OutputBlockSize;
        SIGNED_LONG_INTEGER BlockSize;
        SIGNED_LONG_INTEGER FeedbackSize;
        SIGNED_LONG_INTEGER KeySize;
    };

     class MD4 
    {
        // class delegates

        // class events

        // class functions
        FUNCTION Clear ();
        FUNCTION Initialize ();
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
        SIGNED_LONG_INTEGER HashSize;
        SIGNED_LONG_INTEGER InputBlockSize;
        SIGNED_LONG_INTEGER OutputBlockSize;
    };

     class DiffieHellman 
    {
        // class delegates

        // class events

        // class functions
        FUNCTION ImportParameters ( DHParameters parameters );
        FUNCTION FromXmlString ( STRING xmlString );
        FUNCTION Clear ();
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
        STRING KeyExchangeAlgorithm[];
        SIGNED_LONG_INTEGER KeySize;
        STRING SignatureAlgorithm[];
    };

     class Null 
    {
        // class delegates

        // class events

        // class functions
        FUNCTION Clear ();
        FUNCTION GenerateIV ();
        FUNCTION GenerateKey ();
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
        SIGNED_LONG_INTEGER BlockSize;
        SIGNED_LONG_INTEGER FeedbackSize;
        SIGNED_LONG_INTEGER KeySize;
    };

     class NullManaged 
    {
        // class delegates

        // class events

        // class functions
        FUNCTION GenerateIV ();
        FUNCTION GenerateKey ();
        FUNCTION Clear ();
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
        SIGNED_LONG_INTEGER BlockSize;
        SIGNED_LONG_INTEGER FeedbackSize;
        SIGNED_LONG_INTEGER KeySize;
    };

     class MD2 
    {
        // class delegates

        // class events

        // class functions
        FUNCTION Clear ();
        FUNCTION Initialize ();
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
        SIGNED_LONG_INTEGER HashSize;
        SIGNED_LONG_INTEGER InputBlockSize;
        SIGNED_LONG_INTEGER OutputBlockSize;
    };

    static class DHKeyGeneration // enum
    {
        static SIGNED_LONG_INTEGER Random;
        static SIGNED_LONG_INTEGER Static;
    };

     class MD2Managed 
    {
        // class delegates

        // class events

        // class functions
        FUNCTION Initialize ();
        FUNCTION Clear ();
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
        SIGNED_LONG_INTEGER HashSize;
        SIGNED_LONG_INTEGER InputBlockSize;
        SIGNED_LONG_INTEGER OutputBlockSize;
    };

     class SHA224 
    {
        // class delegates

        // class events

        // class functions
        FUNCTION Clear ();
        FUNCTION Initialize ();
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
        SIGNED_LONG_INTEGER HashSize;
        SIGNED_LONG_INTEGER InputBlockSize;
        SIGNED_LONG_INTEGER OutputBlockSize;
    };

     class SHA224Managed 
    {
        // class delegates

        // class events

        // class functions
        FUNCTION Initialize ();
        FUNCTION Clear ();
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
        SIGNED_LONG_INTEGER HashSize;
        SIGNED_LONG_INTEGER InputBlockSize;
        SIGNED_LONG_INTEGER OutputBlockSize;
    };

     class MD4Managed 
    {
        // class delegates

        // class events

        // class functions
        FUNCTION Initialize ();
        FUNCTION Clear ();
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
        SIGNED_LONG_INTEGER HashSize;
        SIGNED_LONG_INTEGER InputBlockSize;
        SIGNED_LONG_INTEGER OutputBlockSize;
    };

     class DiffieHellmanManaged 
    {
        // class delegates

        // class events

        // class functions
        FUNCTION ImportParameters ( DHParameters parameters );
        FUNCTION FromXmlString ( STRING xmlString );
        FUNCTION Clear ();
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
        STRING KeyExchangeAlgorithm[];
        STRING SignatureAlgorithm[];
        SIGNED_LONG_INTEGER KeySize;
    };

