namespace System.Collections;
        // class declarations

namespace System;
        // class declarations

