namespace ProcessHacker.Common.Threading;
        // class declarations
         class SemaphorePair;
         class FastLock;
         class SpinLock;
         class Interlocked2;
         class FastMutex;
         class FairResourceLock;
         class FastResourceLock;
         class FastEvent;
         class FastEventWH;
     class SpinLock 
    {
        // class delegates

        // class events

        // class functions
        FUNCTION Acquire ();
        FUNCTION Release ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();
        STRING_FUNCTION ToString ();

        // class variables
        INTEGER __class_id__;

        // class properties
    };

    static class Interlocked2 
    {
        // class delegates

        // class events

        // class functions
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
    };

     class FastMutex 
    {
        // class delegates

        // class events

        // class functions
        FUNCTION Acquire ();
        FUNCTION Release ();
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
    };

     class FairResourceLock 
    {
        // class delegates

        // class events

        // class functions
        FUNCTION Dispose ();
        FUNCTION ConvertExclusiveToShared ();
        FUNCTION ConvertSharedToExclusive ();
        FUNCTION ReleaseExclusive ();
        FUNCTION ReleaseShared ();
        FUNCTION ReleaseAny ();
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        static STRING MsgFailedToWaitIndefinitely[];

        // class properties
        SIGNED_LONG_INTEGER SharedOwners;
        SIGNED_LONG_INTEGER SpinCount;
    };

     class FastResourceLock 
    {
        // class delegates

        // class events

        // class functions
        FUNCTION Dispose ();
        FUNCTION ConvertExclusiveToShared ();
        FUNCTION ReleaseAny ();
        FUNCTION ReleaseExclusive ();
        FUNCTION ReleaseShared ();
        FUNCTION SpinConvertSharedToExclusive ();
        FUNCTION ConvertSharedToExclusive ();
        FUNCTION ConvertSharedToExclusiveWithRelease ();
        static FUNCTION Break ( STRING logMessage );
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        static STRING MsgFailedToWaitIndefinitely[];

        // class properties
        SIGNED_LONG_INTEGER ExclusiveWaiters;
        SIGNED_LONG_INTEGER ConvertToExclusiveWaiters;
        SIGNED_LONG_INTEGER SharedOwners;
        SIGNED_LONG_INTEGER SharedWaiters;
    };

namespace Wintellect.Threading;
        // class declarations
         class InterlockedEx;
    static class InterlockedEx 
    {
        // class delegates

        // class events

        // class functions
        static SIGNED_LONG_INTEGER_FUNCTION Add ( BYREF SIGNED_LONG_INTEGER target , SIGNED_LONG_INTEGER value );
        static SIGNED_LONG_INTEGER_FUNCTION Max ( BYREF SIGNED_LONG_INTEGER target , SIGNED_LONG_INTEGER value );
        static SIGNED_LONG_INTEGER_FUNCTION Min ( BYREF SIGNED_LONG_INTEGER target , SIGNED_LONG_INTEGER value );
        static SIGNED_LONG_INTEGER_FUNCTION DecrementIfGreaterThan ( BYREF SIGNED_LONG_INTEGER target , SIGNED_LONG_INTEGER lowValue );
        static SIGNED_LONG_INTEGER_FUNCTION DecrementIfGreaterThanZero ( BYREF SIGNED_LONG_INTEGER target );
        static SIGNED_LONG_INTEGER_FUNCTION AddModulo ( BYREF SIGNED_LONG_INTEGER target , SIGNED_LONG_INTEGER value , SIGNED_LONG_INTEGER modulo );
        static SIGNED_LONG_INTEGER_FUNCTION And ( BYREF SIGNED_LONG_INTEGER target , SIGNED_LONG_INTEGER with );
        static SIGNED_LONG_INTEGER_FUNCTION Or ( BYREF SIGNED_LONG_INTEGER target , SIGNED_LONG_INTEGER with );
        static SIGNED_LONG_INTEGER_FUNCTION Xor ( BYREF SIGNED_LONG_INTEGER target , SIGNED_LONG_INTEGER with );
        static SIGNED_LONG_INTEGER_FUNCTION MaskedAnd ( BYREF SIGNED_LONG_INTEGER target , SIGNED_LONG_INTEGER with , SIGNED_LONG_INTEGER mask );
        static SIGNED_LONG_INTEGER_FUNCTION MaskedOr ( BYREF SIGNED_LONG_INTEGER target , SIGNED_LONG_INTEGER with , SIGNED_LONG_INTEGER mask );
        static SIGNED_LONG_INTEGER_FUNCTION MaskedXor ( BYREF SIGNED_LONG_INTEGER target , SIGNED_LONG_INTEGER with , SIGNED_LONG_INTEGER mask );
        static SIGNED_LONG_INTEGER_FUNCTION MaskedExchange ( BYREF SIGNED_LONG_INTEGER target , SIGNED_LONG_INTEGER mask , SIGNED_LONG_INTEGER value );
        static SIGNED_LONG_INTEGER_FUNCTION MaskedAdd ( BYREF SIGNED_LONG_INTEGER target , SIGNED_LONG_INTEGER value , SIGNED_LONG_INTEGER mask );
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
    };

namespace SSharp.Threading;
        // class declarations
         class WaitHandle;
         class EventWaitHandle;
         class CEventWaitHandle;
         class CEventWH;
         class AutoResetEvent;
         class ManualResetEvent;
         class CMutexWH;
         class EventResetMode;
         class DuplicateWaitObjectException;
         class Semaphore;
         class SemaphoreFullException;
         class ThreadPriority;
     class WaitHandle 
    {
        // class delegates

        // class events

        // class functions
        FUNCTION Close ();
        static SIGNED_LONG_INTEGER_FUNCTION WaitAny ( WaitHandle waitHandles[] );
        FUNCTION Dispose ();
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        static SIGNED_LONG_INTEGER WaitTimeout;

        // class properties
    };

     class EventWaitHandle 
    {
        // class delegates

        // class events

        // class functions
        FUNCTION Close ();
        FUNCTION Dispose ();
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        static SIGNED_LONG_INTEGER WaitTimeout;

        // class properties
    };

     class CMutexWH 
    {
        // class delegates

        // class events

        // class functions
        FUNCTION Close ();
        FUNCTION ReleaseMutex ();
        FUNCTION Dispose ();
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        static SIGNED_LONG_INTEGER WaitTimeout;

        // class properties
    };

    static class EventResetMode // enum
    {
        static SIGNED_LONG_INTEGER AutoReset;
        static SIGNED_LONG_INTEGER ManualReset;
    };

     class DuplicateWaitObjectException 
    {
        // class delegates

        // class events

        // class functions
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
        STRING Message[];
        STRING StackTrace[];
        STRING HelpLink[];
        STRING Source[];
    };

    static class ThreadPriority // enum
    {
        static SIGNED_LONG_INTEGER Lowest;
        static SIGNED_LONG_INTEGER BelowNormal;
        static SIGNED_LONG_INTEGER Normal;
        static SIGNED_LONG_INTEGER AboveNormal;
        static SIGNED_LONG_INTEGER Highest;
    };

namespace SSharp.CrestronThread;
        // class declarations
         class Thread;
         class eThreadPriority;
         class eThreadStartOptions;
         class eThreadStates;
         class eThreadType;
    static class eThreadPriority // enum
    {
        static SIGNED_LONG_INTEGER UberPriority;
        static SIGNED_LONG_INTEGER HighPriority;
        static SIGNED_LONG_INTEGER MediumPriority;
        static SIGNED_LONG_INTEGER LowestPriority;
        static SIGNED_LONG_INTEGER NotSet;
    };

    static class eThreadStartOptions // enum
    {
        static SIGNED_LONG_INTEGER CreateSuspended;
        static SIGNED_LONG_INTEGER Running;
    };

    static class eThreadStates // enum
    {
        static SIGNED_LONG_INTEGER ThreadInvalidState;
        static SIGNED_LONG_INTEGER ThreadCreated;
        static SIGNED_LONG_INTEGER ThreadRunning;
        static SIGNED_LONG_INTEGER ThreadSuspended;
        static SIGNED_LONG_INTEGER ThreadAborting;
        static SIGNED_LONG_INTEGER ThreadFinished;
    };

    static class eThreadType // enum
    {
        static SIGNED_LONG_INTEGER SystemThread;
        static SIGNED_LONG_INTEGER UserThread;
    };

namespace System;
        // class declarations
         class LazyThreadSafetyMode;
    static class LazyThreadSafetyMode // enum
    {
        static SIGNED_LONG_INTEGER None;
        static SIGNED_LONG_INTEGER PublicationOnly;
        static SIGNED_LONG_INTEGER ExecutionAndPublication;
    };

namespace Crestron.SimplSharp;
        // class declarations
         class CEventHandleEx;
         class DuplicateWaitObjectException;
     class CEventHandleEx 
    {
        // class delegates

        // class events

        // class functions
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        static SIGNED_LONG_INTEGER WaitTimeout;

        // class properties
    };

     class DuplicateWaitObjectException 
    {
        // class delegates

        // class events

        // class functions
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
        STRING Message[];
        STRING StackTrace[];
        STRING HelpLink[];
        STRING Source[];
    };

